from http.client import HTTPResponse
from multiprocessing import context
from django import forms
from django.shortcuts import redirect, render
from django.urls import is_valid_path
from .models import Usuario
from .forms import UsuarioForm
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm
from .forms import UsuarioForm, UserRegistrationForm
from django.contrib.auth.decorators import login_required

# Create your views here.

def inicio(request):
    return render(request,'aplicacion1/index.html')

def contactos(request):
    return render(request,'aplicacion1/contactos.html')

@login_required
def usuarios(request):
    usuario=Usuario.objects.all()
    return render(request, 'aplicacion1/usuarios.html', {"data":usuario})
    
@login_required
def usuarios2(request):
    form = UsuarioForm()
    
    if request.method == "POST":
        form = UsuarioForm(data = request.POST)
        if form.is_valid():
            usuario = form.save(commit=False)
            usuario.save()
        return redirect('/usuarios')
    else:
        form= UsuarioForm()
        return render(request, 'aplicacion1/crearusuario.html', {'form': form})

def register(request):
    if request.method == "POST":
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data['username']
            messages.success(request, f'Usuario {username} creado exitosamente.')
            return redirect('login')
    
    else:
        form = UserRegistrationForm()
    
    context = {'form': form}

    return render(request, 'aplicacion1/register.html', context)

@login_required
def bienvenido(request):
    
    return render(request,"aplicacion1/bienvenido.html")
    