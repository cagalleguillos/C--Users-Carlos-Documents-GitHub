from unicodedata import name
from django.urls import path, include
from . import views
from django.contrib.auth.views import LoginView, LogoutView

urlpatterns = [
    
    path('',views.inicio, name='inicio'),
    path('contactos/',views.contactos,name='contactos'),
    path('usuarios', views.usuarios, name='usuarios'),
    path('recibirReclamo',views.reclamo, name='reclamo'),
    path('usuario2',views.usuarios2),
    path('register/', views.register, name="register"),
    path('bienvenido/', views.bienvenido, name="bienvenido")
]