from django.contrib import admin
from .models import Comentario, Usuario, Soporte_Tecnico, Comercial

# Register your models here.

admin.site.register(Usuario)
admin.site.register(Soporte_Tecnico)
admin.site.register(Comercial)
admin.site.register(Comentario)