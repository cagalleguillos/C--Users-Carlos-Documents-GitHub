from http.client import HTTPResponse
from multiprocessing import context
from django import forms
from django.shortcuts import redirect, render
from django.urls import is_valid_path
from .models import Usuario, Soporte_Tecnico, Comentario
from .forms import UsuarioForm, ComentarioForm
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm
from .forms import UsuarioForm, UserRegistrationForm
from django.contrib.auth.decorators import login_required

# Create your views here.

def inicio(request):
    return render(request,'aplicacion1/index.html')

def contactos(request):
    return render(request,'aplicacion1/contactos.html')

@login_required
def usuarios(request):
    usuario=Usuario.objects.all()
    return render(request, 'aplicacion1/usuarios.html', {"data":usuario})
    
@login_required
def usuarios2(request):
    form = UsuarioForm()
    
    if request.method == "POST":
        form = UsuarioForm(data = request.POST)
        if form.is_valid():
            usuario = form.save(commit=False)
            usuario.save()
        return redirect('/usuarios')
    else:
        form= UsuarioForm()
        return render(request, 'aplicacion1/crearusuario.html', {'form': form})

def register(request):
    if request.method == "POST":
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data['username']
            messages.success(request, f'Usuario {username} creado exitosamente.')
            return redirect('login')
    
    else:
        form = UserRegistrationForm()
    
    context = {'form': form}

    return render(request, 'aplicacion1/register.html', context)

@login_required
def bienvenido(request):
    
    return render(request,"aplicacion1/bienvenido.html")

def soportes(request):
    soporte_tecnico=Soporte_Tecnico.objects.all()
    return render(request, 'aplicacion1/soportetecnico.html', {"data":soporte_tecnico})
def comentario_clientes(request):
    
    if request.method == 'POST':
        
        form = ComentarioForm(request.POST)

        if form.is_valid():

            com=Comentario()
            com.nombre=form.cleaned_data["nombre"]
            com.apellido=form.cleaned_data["apellido"]
            com.correo=form.cleaned_data["correo"]
            com.comentario=form.cleaned_data["comentario"]
            '''com = form.save(commit=False)'''
            com.save()
        return redirect('comentario_clientes')

    else:
        print('invalido')
        form = ComentarioForm()
        return render(request, 'aplicacion1/comentario_clientes.html', {'form':form})

def lista_comentarios(request):
    com=Comentario.objects.all()
    return render (request, 'aplicacion1/lista_comentarios.html', {"data":com})

def editar_comentario(request, id):
    comentario = Comentario.objects.get(pk=id)
    form = ComentarioForm(instance=comentario)
    if request.method == 'POST':
        
        form = ComentarioForm(data=request.POST, instance=comentario)
        form.save()
        return redirect('lista_comentarios')

    else:
        return render(request, 'aplicacion1/editar_comentario.html', {'form':form})

def eliminar_comentario(request, id):
        comentario = Comentario.objects.get(pk=id)
        comentario.delete()
        return redirect('/lista_comentarios')

def listar_coment_mail(request,correo):
    email_list = Comentario.objects.filter(correo=correo)
    return render(request, 'aplicacion1/lista_comentarios.html', {"correo":email_list})
