from pyexpat import model
from django import forms
from django.db.models import fields
from .models import Comentario, Usuario
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User


class UsuarioForm(forms.ModelForm):
    class Meta:
        model=Usuario
        fields=('nombre','apellido','email')

class UserRegistrationForm(UserCreationForm):
    email = forms.EmailField()
    password = forms.CharField(label="Contraseña", widget=forms.PasswordInput)
    password2 = forms.CharField(label="Confirmación contraseña", widget=forms.PasswordInput)

    class Meta:
        model=User
        fields= ['username', 'email', 'password', 'password2']
        help_texts = {k: "" for k in fields}

class ComentarioForm (forms.ModelForm):
    class Meta:
        model=Comentario
        fields=('nombre','apellido','correo','comentario',)
    
