from unicodedata import name
from django.urls import path, include
from . import views
from django.contrib.auth.views import LoginView, LogoutView

urlpatterns = [
    
    path('',views.inicio, name='inicio'),
    path('contactos/',views.contactos,name='contactos'),
    path('usuarios', views.usuarios, name='usuarios'),
    path('usuario2',views.usuarios2, name='usuario2'),
    path('register/', views.register, name="register"),
    path('bienvenido/', views.bienvenido, name="bienvenido"),
    path('soportetecnico', views.soportes, name='soporte_tecnico'),
    path('comentario_clientes/', views.comentario_clientes, name='comentario_clientes'),
    path('lista_comentarios/', views.lista_comentarios, name='lista_comentarios'),
    path('editar_comentario/<int:id>/', views.editar_comentario, name='editar_comentario'),
    path('eliminar_comentario/<int:id>/', views.eliminar_comentario, name='eliminar_comentario'),
    path ('lista_coment_mail/<str:correo>/', views.listar_coment_mail, name='lista_coment_mail'),    
]

    
